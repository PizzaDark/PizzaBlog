package com.pizza.myblogsystem.controller;

import com.pizza.myblogsystem.dto.user.UserDto;
import com.pizza.myblogsystem.dto.user.UserListPageDto;
import com.pizza.myblogsystem.entity.Admin;
import com.pizza.myblogsystem.entity.User;
import com.pizza.myblogsystem.service.IAdminService;
import com.pizza.myblogsystem.service.IArticleService;
import com.pizza.myblogsystem.service.IArticleTagService;
import com.pizza.myblogsystem.service.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.ui.Model;
import org.springframework.validation.support.BindingAwareModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import static org.junit.jupiter.api.Assertions.*;

class AdminControllerTest {

    private AdminController adminController;
    private IArticleTagService iArticleTagService;
    private IArticleService iArticleService;
    private IUserService iUserService;
    private IAdminService iAdminService;
    private HttpServletRequest request;
    private HttpSession session;
    private Model model;

    @BeforeEach
    void setUp() {
        // 初始化服务和请求
        IArticleTagService iArticleTagService;
        IArticleService iArticleService;
        IUserService iUserService;
        IAdminService iAdminService;
        HttpServletRequest request;
        HttpSession session;
        model = new BindingAwareModelMap();

//        // 初始化AdminController
//        adminController = new AdminController();
//        adminController.setIArticleTagService(iArticleTagService);
//        adminController.setIArticleService(iArticleService);
//        adminController.setIUserService(iUserService);
//        adminController.setIAdminService(iAdminService);
    }

    @Test
    void adminLogin() {
        String adminName = "admin";
        String adminPassword = "password";
        String captcha = "1234";
        session.setAttribute("circleCaptchaCode", captcha);

        String result = String.valueOf(adminController.adminLogin(request, adminName, adminPassword, captcha));
        assertEquals("登录成功", result);
    }

    @Test
    void adminLogout() {
        session.setAttribute("admin", new Admin());
        session.setAttribute("adminLogged", true);

        String result = adminController.adminLogout(request);
        assertEquals("redirect:/adminpizza/login", result);
    }

    @Test
    void adminIndex() {
        String result = adminController.adminIndex(model);
        assertEquals("/admin/index", result);
    }

    @Test
    void userList() {
        UserListPageDto userListPageDto = new UserListPageDto();
        userListPageDto.setPageNumber(1);
        userListPageDto.setPageSize(10);

        String result = adminController.userList(userListPageDto, model);
        assertEquals("/admin/userList", result);
    }

    @Test
    void userDel() {
        String userId = "1";
        String result = String.valueOf(adminController.userDel(userId));
        assertEquals("用户"+userId+"已被成功删除", result);
    }

    @Test
    void userUpdate() {
        UserDto userDto = new UserDto();
        userDto.setUserId("1");
        userDto.setUserPassword("password");

        String result = String.valueOf(adminController.userUpdate(userDto));
        assertEquals("保存成功", result);
    }
}