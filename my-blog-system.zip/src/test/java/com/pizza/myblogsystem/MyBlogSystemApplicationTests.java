package com.pizza.myblogsystem;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.crypto.SecureUtil;
import com.pizza.myblogsystem.entity.Admin;
import com.pizza.myblogsystem.entity.User;
import com.pizza.myblogsystem.service.IAdminService;
import com.pizza.myblogsystem.service.IUserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.xml.crypto.Data;
import java.util.ArrayList;
import java.util.Date;

@SpringBootTest
class MyBlogSystemApplicationTests {

    @Autowired
    private IAdminService iAdminService;
    @Autowired
    private IUserService iUserService;

//    @Test
//    void contextLoads() {
//        ArrayList<User> users = new ArrayList<>();
//        for (int i=0;i<50;i++){
//            User user = new User();
//            user.setUserName("测试用户"+i);
//            user.setUserId("testuser"+i);
//            user.setUserPassword(SecureUtil.md5("123456"));
//            user.setUserRegisterTime(DateUtil.date());
//            users.add(user);
//        }
//        iUserService.saveBatch(users,50);
//    }

//    @Test
//    public void addAdmin(){
//        Admin admin = new Admin();
//        admin.setAdminName("Pizza");
//        admin.setAdminId("a0001");
//        admin.setAdminPassword(SecureUtil.md5(admin.getAdminName()+"yyr123456"));
//        iAdminService.save(admin);
//    }

}
