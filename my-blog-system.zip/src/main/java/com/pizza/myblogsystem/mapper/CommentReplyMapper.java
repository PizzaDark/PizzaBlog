package com.pizza.myblogsystem.mapper;

import com.pizza.myblogsystem.entity.CommentReply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 评论回复表 Mapper 接口
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface CommentReplyMapper extends BaseMapper<CommentReply> {

}
