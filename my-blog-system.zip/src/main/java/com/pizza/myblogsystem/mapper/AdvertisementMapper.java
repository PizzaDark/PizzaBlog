package com.pizza.myblogsystem.mapper;

import com.pizza.myblogsystem.entity.Advertisement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 广告 Mapper 接口
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface AdvertisementMapper extends BaseMapper<Advertisement> {

}
