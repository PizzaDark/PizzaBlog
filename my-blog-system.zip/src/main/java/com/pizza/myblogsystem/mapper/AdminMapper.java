package com.pizza.myblogsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pizza.myblogsystem.entity.Admin;

/**
 * <p>
 * 管理员表 Mapper 接口
 * </p>
 *
 * @author 侯征
 * @since 2023-08-10
 */
public interface AdminMapper extends BaseMapper<Admin> {
}
