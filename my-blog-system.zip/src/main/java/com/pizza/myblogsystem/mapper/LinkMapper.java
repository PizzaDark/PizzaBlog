package com.pizza.myblogsystem.mapper;

import com.pizza.myblogsystem.entity.Link;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 链接 Mapper 接口
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface LinkMapper extends BaseMapper<Link> {

}
