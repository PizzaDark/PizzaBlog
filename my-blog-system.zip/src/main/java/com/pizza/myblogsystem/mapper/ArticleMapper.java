package com.pizza.myblogsystem.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.entity.Article;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pizza.myblogsystem.vo.ArticleVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * 文章表 Mapper 接口
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Component
public interface ArticleMapper extends BaseMapper<Article> {

    /**
     * 文章列表
     * @param articlePage
     * @param articleTitle
     * @param userId
     * @return
     */
    IPage<ArticleVo> articleList(IPage<ArticleVo> articlePage, @Param("articleTitle") String articleTitle,@Param("userId") String userId);

    /**
     * 文章列表方法
     * @param articlePage
     * @param articleTitle
     * @return
     */
    IPage<ArticleVo> articleListView(Page<ArticleVo> articlePage,String articleTitle);

    /**
     * 最新文章
     * @return
     */
    List<ArticleVo> getIndexArticleList();

    /**
     * 根据id获取文章
     * @param articleId
     * @return
     */
    Article getArticle(@Param("articleId") String articleId);

}
