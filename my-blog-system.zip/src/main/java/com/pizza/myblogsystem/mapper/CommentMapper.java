package com.pizza.myblogsystem.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.entity.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pizza.myblogsystem.vo.CommentVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * 评论表 Mapper 接口
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Component
public interface CommentMapper extends BaseMapper<Comment> {

    /**
     * 文章评论列表
     * @param articleId
     * @return
     */
    IPage<CommentVo> getCommentList(Page<CommentVo> commentVoPage, @Param("articleId") String articleId);

}
