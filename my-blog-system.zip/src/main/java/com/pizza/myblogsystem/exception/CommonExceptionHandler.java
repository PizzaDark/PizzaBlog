package com.pizza.myblogsystem.exception;

import com.pizza.myblogsystem.utils.CommonResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.nio.charset.CoderResult;

@RestControllerAdvice
public class CommonExceptionHandler {

//    @ExceptionHandler(CommonException.class)
//    public CommonResult handleRRException(CommonException e){
//        return new CommonResult(e.getCode(),e.getMessage());
//    }
//
//    @ExceptionHandler(Exception.class)
//    public CoderResult excption(Exception e){
//        e.printStackTrace();
//        CommonResult commonResult = new  CommonResult(500,e.getMessage());
//        return commonResult;
//    }
}
