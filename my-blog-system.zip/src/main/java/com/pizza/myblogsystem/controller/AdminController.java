package com.pizza.myblogsystem.controller;

import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.system.HostInfo;
import cn.hutool.system.OsInfo;
import cn.hutool.system.SystemUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.dto.user.UserDto;
import com.pizza.myblogsystem.dto.user.UserListPageDto;
import com.pizza.myblogsystem.entity.Admin;
import com.pizza.myblogsystem.entity.User;
import com.pizza.myblogsystem.service.IAdminService;
import com.pizza.myblogsystem.service.IArticleService;
import com.pizza.myblogsystem.service.IArticleTagService;
import com.pizza.myblogsystem.service.IUserService;
import com.pizza.myblogsystem.utils.CommonPage;
import com.pizza.myblogsystem.utils.CommonResult;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.Objects;

@Controller
@RequestMapping("/adminpizza")
public class AdminController {

    @Autowired
    private IArticleTagService iArticleTagService;
    @Autowired
    private IArticleService iArticleService;
    @Autowired
    private IUserService iUserService;
    @Autowired
    private IAdminService iAdminService;

    /**
     * 登录页面
     * @return
     */
    @GetMapping("/login")
    public String adminLogin(HttpServletRequest request){
        if (Objects.nonNull(request.getSession().getAttribute("admin"))){
            return "redirect:/adminpizza/";
        }
        return "admin/adminLogin";
    }

    /**
     * 管理员登录
     * @param request
     * @param adminName
     * @param adminPassword
     * @param captcha
     * @return
     */
    @PostMapping("/adminLogin")
    @ResponseBody
    public CommonResult adminLogin(HttpServletRequest request,
                                   @Length(min = 3,max = 25,message = "用户名长度为3-25个字符") String adminName,
                                   @Length(min = 3,max = 25,message = "密码长度为3-25个字符") String adminPassword,
                                   String captcha){
        HttpSession session = request.getSession();
        if (StrUtil.isBlank(captcha)||!captcha.equals(session.getAttribute("circleCaptchaCode"))){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("验证码不正确");
        }
        Admin admin = iAdminService.getOne(Wrappers.<Admin>lambdaQuery()
                .eq(Admin::getAdminName,adminName)
                .eq(Admin::getAdminPassword,SecureUtil.md5(adminName+adminPassword)),false);
        if (Objects.isNull(admin)){
            return CommonResult.failed("用户名或密码不正确");
        }
        session.setAttribute("admin",admin);
        session.setAttribute("adminLogged",true);

        return CommonResult.success("登录成功");
    }

    /**
     * 登出
     * @param servletRequest
     * @return
     */
    @GetMapping("/logout")
    public String adminLogout(HttpServletRequest servletRequest){
        servletRequest.getSession().removeAttribute("admin");
        servletRequest.getSession().removeAttribute("adminLogged");
        return "redirect:/adminpizza/login";
    }

    /**
     * 管理端 - 首页
     * @param model
     * @return
     */
    @GetMapping("/")
    public String adminIndex(Model model){

        //系统信息
        OsInfo osInfo = SystemUtil.getOsInfo();
        HostInfo hostInfo = SystemUtil.getHostInfo();
        model.addAttribute("osName",osInfo.getName());
        model.addAttribute("hostAddress",hostInfo.getAddress());

        //文章数量
        int articleTagCount = iArticleTagService.count();
        int articleCount = iArticleService.count();
        model.addAttribute("articleCount",articleCount);
        model.addAttribute("articleTagCount",articleTagCount);

        //用户数量
        int userCount = iUserService.count();
        model.addAttribute("userCount",userCount);

        return "/admin/index";
    }

    /**
     * 管理端 - 用户列表
     * @param userListPageDto
     * @param model
     * @return
     */
    @GetMapping("/user/list")
    public String userList(UserListPageDto userListPageDto, Model model){
        Integer pageNumber = userListPageDto.getPageNumber();
        Integer pageSize = userListPageDto.getPageSize();
        String userName = userListPageDto.getUserName();

        IPage<User> userPage = new Page<>(pageNumber,pageSize);
        LambdaQueryWrapper<User> userLambdaQueryWrapper = Wrappers.<User>lambdaQuery().orderByDesc(User::getUserRegisterTime);

        if (StrUtil.isNotBlank(userName)){
            userLambdaQueryWrapper.like(User::getUserName,userName);
            model.addAttribute("userName",userName);
        }

        IPage<User> userIPage = iUserService.page(userPage,userLambdaQueryWrapper);
        model.addAttribute("userPage", CommonPage.restPage(userPage));

        return "/admin/userList";
    }

    /**
     * 删除用户
     * @param userId
     * @return
     */
    @PostMapping("/user/del")
    @ResponseBody
    public CommonResult userDel(String userId){
        if (StrUtil.isBlank(userId)){
            return CommonResult.failed("错误，请重试");
        }

        if (iUserService.removeById(userId)){
            return CommonResult.success("用户"+userId+"已被成功删除");
        }

        return CommonResult.failed("删除失败");
    }

    @PostMapping("/user/update")
    @ResponseBody
    public CommonResult userUpdate(UserDto userDto){
        User user = iUserService.getById(userDto.getUserId());
        if (Objects.isNull(user)){
            return CommonResult.failed("用户id不正确");
        }
        Date userRegisterTime = user.getUserRegisterTime();

        String userPassword = userDto.getUserPassword();
        if (StrUtil.isNotBlank(userPassword)){
            userDto.setUserPassword(SecureUtil.md5(userRegisterTime+userPassword));
        }
        else {
            userDto.setUserPassword(null);
        }
        BeanUtils.copyProperties(userDto,user);
        if (iUserService.updateById(user)){
            return CommonResult.success("保存成功");
        }

        return CommonResult.failed("修改失败");
    }
}
