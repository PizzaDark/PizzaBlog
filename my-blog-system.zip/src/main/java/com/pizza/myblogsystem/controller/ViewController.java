package com.pizza.myblogsystem.controller;

import cn.hutool.captcha.CircleCaptcha;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.dto.user.UserInfoDto;
import com.pizza.myblogsystem.entity.*;
import com.pizza.myblogsystem.service.*;
import com.pizza.myblogsystem.utils.CommonPage;
import com.pizza.myblogsystem.utils.CommonResult;
import com.pizza.myblogsystem.utils.CommonUtils;
import com.pizza.myblogsystem.vo.CommentVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Controller
public class ViewController {

    @Autowired
    private IUserService iUserService;
    @Autowired
    private IArticleService iArticleService;
    @Autowired
    private IArticleTagService iArticleTagService;
    @Autowired
    private ILinkService iLinkService;
    @Autowired
    private ICommentService iCommentService;

    /**
     * 获取图像验证码
     * @param request
     * @param response
     * @throws IOException
     */
    @GetMapping("/getCaptcha")
    public void getCaptcha(HttpServletRequest request, HttpServletResponse response) throws IOException{
        CircleCaptcha captcha = CommonUtils.getCaptcha(request);
        captcha.write(response.getOutputStream());
    }

    /**
     * 用户注册页面
     * @param request
     * @return
     */
    @GetMapping("/register")
    public String register(HttpServletRequest request){
        if (Objects.nonNull(request.getSession().getAttribute("user"))){
            return "redirect:/";
        }
        return "/view/register";
    }

    /**
     * 用户注册方法
     * @param request
     * @param userInfoDto
     * @return
     */
    @PostMapping("/userRegister")
    @ResponseBody
    public CommonResult userRegister(HttpServletRequest request, UserInfoDto userInfoDto){
        HttpSession session = request.getSession();
        String captcha = userInfoDto.getCaptcha();
        if (StrUtil.isBlank(captcha)||!captcha.equals(session.getAttribute("circleCaptchaCode"))){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("验证码不正确");
        }
        if (userInfoDto.getUserName().equals(userInfoDto.getUserPassword())){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("用户名不能和密码相同");
        }
        if (iUserService.count(Wrappers.<User>lambdaQuery().eq(User::getUserName,userInfoDto.getUserId())) > 0){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("用户名已被占用");
        }

        User user = new User();
        BeanUtils.copyProperties(userInfoDto,user);
        user.setUserId(IdUtil.simpleUUID());
        user.setUserRegisterTime(DateUtil.date());
        user.setUserPassword(SecureUtil.md5(user.getUserId() + user.getUserPassword()));
        if (iUserService.save(user)){
            return CommonResult.success("注册成功");
        }
        return CommonResult.failed("注册失败，请重试");
    }

    /**
     * 用户登陆页面
     * @param request
     * @param model
     * @return
     */
    @GetMapping("/login")
    private String login(HttpServletRequest request,Model model){
        if (Objects.nonNull(request.getSession().getAttribute("user"))){
            return "redirect:/";
        }
        model.addAttribute("referer",request.getHeader("referer"));
        return "/view/login";
    }

    /**
     * 用户登录方法
     * @param request
     * @param userInfoDto
     * @return
     */
    @PostMapping("/userLogin")
    @ResponseBody
    public CommonResult userLogin(HttpServletRequest request, UserInfoDto userInfoDto){
        HttpSession session = request.getSession();
        String captcha = userInfoDto.getCaptcha();
        if (StrUtil.isBlank(captcha)||!captcha.equals(session.getAttribute("circleCaptchaCode"))){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("验证码不正确");
        }
        if (userInfoDto.getUserName().equals(userInfoDto.getUserPassword())){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("用户名不能和密码相同");
        }

        User userDb = iUserService.getOne(Wrappers.<User>lambdaQuery().eq(User::getUserName,userInfoDto.getUserName()),false);
        if (Objects.isNull(userDb)){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("用户名错误");
        }
        if (!SecureUtil.md5(userDb.getUserId() + userInfoDto.getUserPassword()).equals(userDb.getUserPassword())){
            session.removeAttribute("circleCaptchaCode");
            return CommonResult.failed("密码错误");
        }
        session.setAttribute("userLogged",true);
        session.setAttribute("user",userDb);
        return CommonResult.success("登录成功");
    }

    /**
     * 用户登出
     * @param request
     * @return
     */
    @GetMapping("/logout")
    public String logout(HttpServletRequest request){
        request.getSession().removeAttribute("userLogged");
        request.getSession().removeAttribute("user");
        return "/";
    }

    /**
     * 首页
     * @param request
     * @param model
     * @return
     */
    @GetMapping("/")
    public String index(HttpServletRequest request,Model model){
        ServletContext servletContext = request.getServletContext();

        //热门文章
        List<Article> articleHotList = (List<Article>)servletContext.getAttribute("articleHotList");
        if (CollUtil.isEmpty(articleHotList)){
            articleHotList = iArticleService.list(Wrappers.<Article>lambdaQuery().select(Article::getArticleId,Article::getArticleTitle));
            servletContext.setAttribute("articleHotList",articleHotList);
        }

        //热门标签
        List<ArticleTag> articleTagList = (List<ArticleTag>)servletContext.getAttribute("articleTagList");
        if (CollUtil.isEmpty(articleTagList)){
            articleTagList = iArticleTagService.list(Wrappers.<ArticleTag>lambdaQuery().select(ArticleTag::getArticleTagId,ArticleTag::getArticleTagName));
            servletContext.setAttribute("articleTagList",articleTagList);
        }

        //最新文章
//        List<ArticleVo> indexArticleList = (List<ArticleVo>) servletContext.getAttribute("indexArticleList");
//        if (CollUtil.isEmpty(indexArticleList)){
//            indexArticleList = iArticleService.getIndexArticleList();
//            servletContext.setAttribute("indexArticleList",indexArticleList);
//        }

        //友情链接
        List<Link> linkList = (List<Link>) servletContext.getAttribute("linkList");
        if (CollUtil.isEmpty(linkList)){
            linkList = iLinkService.list(Wrappers.<Link>lambdaQuery().orderByAsc(Link::getLinkUrl));
            servletContext.setAttribute("linkList",linkList);
        }

        return "/view/index";
    }

//    /**
//     * 文章列表
//     * @param pageNumber
//     * @param articleTitle
//     * @param model
//     * @return
//     */
//    @GetMapping("/article/list")
//    public String articleListView(Integer pageNumber, String articleTitle, Model model){
//
//    }

    /**
     * 文章
     * @param articleId
     * @param model
     * @return
     */
    @GetMapping("/article")
    public String articleView(String articleId,Model model){
        Article article = iArticleService.getById(articleId);
        User user = iUserService.getById(article.getUserId());

//        Article article0 = iArticleService.getArticle(articleId);//原getById
//
//        Article article = iArticleService.getOne(Wrappers.<Article>lambdaQuery()//
//                .eq(Article::getArticleId, article0.getArticleId())//
//                .select(Article::getArticleId, Article::getArticleView), false);//

        //浏览次数
        Integer articleViewNumber = article.getArticleView();
        if (Objects.isNull(articleViewNumber)||articleViewNumber<0){
            articleViewNumber = 0;
        }
        ++articleViewNumber;
        article.setArticleView(articleViewNumber);
        iArticleService.updateById(article);

        //文章
        model.addAttribute("article",article);
        model.addAttribute("user",user);

        //文章评论
//        List<CommentVo> commentList = iCommentService.getCommentList(article.getArticleId());
        List<Comment> commentList = iCommentService.list(Wrappers.<Comment>lambdaQuery().eq(Comment::getArticleId,articleId).select().orderByAsc(Comment::getCommentTime));
        List<CommentVo> commentVoList = new ArrayList<CommentVo>();
        for (Comment c: commentList){
            User user1 = iUserService.getById(c.getUserId());
            CommentVo commentVo1 = new CommentVo();
            commentVo1.setArticleId(c.getArticleId());
            commentVo1.setCommentContent(c.getCommentContent());
            commentVo1.setCommentId(c.getCommentId());
            commentVo1.setCommentTime(c.getCommentTime());
            commentVo1.setUserId(c.getUserId());
            commentVo1.setCommentThumbs(c.getCommentThumbs());
            commentVo1.setUserName(user1.getUserName());
            commentVoList.add(commentVo1);
        }
        model.addAttribute("commentVoList",commentVoList);

        return "/view/article";
    }

    /**
     * 评论分页
     * @param articleId
     * @param pageNumber
     * @return
     */
    @PostMapping("/comment/list")
    @ResponseBody
    public CommonResult commentList(String articleId,Integer pageNumber){
        if (StrUtil.isBlank(articleId)){
            return CommonResult.failed("评论获取文章id失败");
        }
        if (Objects.isNull(pageNumber)||pageNumber < 1){
            pageNumber = 1;
        }
        Page<CommentVo> commentVoPage = new Page<>(pageNumber,5);
        IPage<CommentVo> commentVoIPage = iCommentService.getCommentList(commentVoPage,articleId);
        return CommonResult.success(CommonPage.restPage(commentVoIPage));
    }

    /**
     * 文章点赞
     * @param request
     * @param articleId
     * @return
     */
    @PostMapping("/articleThumb")
    @ResponseBody
    public CommonResult articleThumb(HttpServletRequest request,String articleId){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (!Objects.nonNull(user)){
            return CommonResult.failed("请先登录");
        }
        if (Objects.nonNull(session.getAttribute("thumbTime"))){
            return CommonResult.failed("点赞过于频繁");
        }
        Article article = iArticleService.getById(articleId);
        article.setArticleThumbs(article.getArticleThumbs()+1);
        if (iArticleService.updateById(article)){
            session.setAttribute("thumbTime",true);
            return CommonResult.success("点赞成功");
        }
        return CommonResult.failed("点赞失败");
    }

    /**
     * 文章收藏
     * @param request
     * @param articleId
     * @return
     */
    @PostMapping("/articleCollection")
    @ResponseBody
    public CommonResult articleCollection(HttpServletRequest request,String articleId){
        User user = (User) request.getSession().getAttribute("user");
        if (!Objects.nonNull(user)){
            return CommonResult.failed("请先登录");
        }

//        Article article = iArticleService.getById(articleId);
//        if (Objects.nonNull(article)){
//            article.setArticleCollection(article.getArticleCollection()+1);
//        }

        return CommonResult.failed("收藏失败");
    }

    /**
     * 评论点赞
     * @param request
     * @param commentId
     * @return
     */
    @PostMapping("/commentThumb")
    @ResponseBody
    public CommonResult commentThumb(HttpServletRequest request,String commentId){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (!Objects.nonNull(user)){
            return CommonResult.failed("请先登录");
        }

        if (StrUtil.isBlank(commentId)){
            return CommonResult.failed("评论不存在");
        }

        HashMap<String,Long> commentThumbMap = (HashMap<String, Long>) session.getAttribute("commentThumbMap");
        if (CollUtil.isNotEmpty(commentThumbMap)&&Objects.nonNull(commentThumbMap.get(commentId))){
            Long commentThumbTime = commentThumbMap.get(commentId);
            if (commentThumbTime+360>=DateUtil.currentSeconds()){
                return CommonResult.failed("点赞太快");
            }
        } else {
            commentThumbMap = new HashMap<>();
        }

        Comment comment = iCommentService.getById(commentId);
        if (Objects.isNull(comment)){
            return CommonResult.failed("点赞失败");
        }

        if (iCommentService.updateById(comment.setCommentThumbs(comment.getCommentThumbs()+1))){
            commentThumbMap.put(commentId,DateUtil.currentSeconds());
            session.setAttribute("commentThumbMap",commentThumbMap);
            return CommonResult.success("点赞成功");
        }
        return CommonResult.failed("点赞失败");
    }

//    /**
//     * 搜索文章
//     *
//     * @param request
//     * @param articleTitle
//     * @return
//     */
//    @GetMapping("/article/search")
//    public String articleSearch(HttpServletRequest request, Integer pageNumber, String articleTitle, Model model) {
//        if (StrUtil.isBlank(articleTitle)) {
//            return "/";
//        }
//        articleTitle = articleTitle.trim();
//        model.addAttribute("articleTitle", articleTitle);
//        if (Objects.isNull(pageNumber) || pageNumber < 1) {
//            pageNumber = 1;
//        }
//        String ipAddr = CommonUtils.getIpAddr(request);
//        ServletContext servletContext = request.getServletContext();
//        ConcurrentMap<String, Long> articleSearchMap = (ConcurrentMap<String, Long>) servletContext.getAttribute("articleSearchMap");
//        if (CollUtil.isEmpty(articleSearchMap) || Objects.isNull(articleSearchMap.get(ipAddr))) {
//            articleSearchMap = new ConcurrentHashMap<>();
//            articleSearchMap.put(ipAddr, DateUtil.currentSeconds());
//        } else {
//            if ((articleSearchMap.get(ipAddr) + 1 > DateUtil.currentSeconds())) {
//                return "/view/searchError";
//            }
//        }
//        //查询到的文章列表
//        List<Article> articleList = new ArrayList<>();
//
//        //拆分搜索词,查询标签
//        List<Word> words = WordSegmenter.seg(articleTitle);
//        List<String> titleList = words.stream().map(Word::getText).collect(Collectors.toList());
//        titleList.add(articleTitle);
//        List<String> articleTagIdList = iArticleTagService.list(Wrappers.<ArticleTag>lambdaQuery()
//                .in(ArticleTag::getArticleTagName, titleList)
//                .select(ArticleTag::getArticleTagId)).stream().map(ArticleTag::getArticleTagId).collect(Collectors.toList());
//        List<String> articleIdList = new ArrayList<>();
//        if (CollUtil.isNotEmpty(articleTagIdList)) {
//            articleIdList = iArticleTagListService.list(Wrappers.<ArticleTagList>lambdaQuery()
//                            .in(ArticleTagList::getArticleTagId, articleTagIdList)
//                            .select(ArticleTagList::getArticleId)).stream()
//                    .map(ArticleTagList::getArticleId).collect(Collectors.toList());
//
//        }
//
//        //分页查询
//        IPage<Article> articlePage = new Page<>(pageNumber, 12);
//        LambdaQueryWrapper<Article> queryWrapper = Wrappers.<Article>lambdaQuery()
//                .like(Article::getArticleTitle, articleTitle)
//                .select(Article::getArticleId,
//                        Article::getArticleCollection,
//                        Article::getArticleView,
//                        Article::getArticlePublishTime,
//                        Article::getArticleTitle);
//        if (CollUtil.isNotEmpty(articleIdList)) {
//            queryWrapper.or().in(Article::getArticleId, articleIdList);
//        }
//
//        IPage<Article> articleIPage = iArticleService.page(articlePage, queryWrapper);
//        model.addAttribute("articleIPage", CommonPage.restPage(articleIPage));
//
//        //保持搜索时间
//        articleSearchMap.put(ipAddr, DateUtil.currentSeconds());
//        servletContext.setAttribute("articleSearchMap", articleSearchMap);
//
//        return "/view/articleSearch";
//    }

}
