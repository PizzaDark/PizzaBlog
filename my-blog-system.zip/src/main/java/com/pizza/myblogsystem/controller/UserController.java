package com.pizza.myblogsystem.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.pizza.myblogsystem.dto.Article.PublishArticleActionDto;
import com.pizza.myblogsystem.entity.Article;
import com.pizza.myblogsystem.entity.ArticleTag;
import com.pizza.myblogsystem.entity.Comment;
import com.pizza.myblogsystem.entity.User;
import com.pizza.myblogsystem.service.*;
import com.pizza.myblogsystem.utils.CommonResult;
import com.pizza.myblogsystem.utils.CommonUtils;
import com.pizza.myblogsystem.vo.CommentVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private IArticleService iArticleService;
    @Autowired
    private IArticleTagService iArticleTagService;
    @Autowired
    private IUserService iUserService;
    @Autowired
    private ICommentService iCommentService;
//    @Autowired
//    private ICommentReplyService iCommentReplyService;

//    /**
//     * 用户收藏
//     * @param request
//     * @param pageNumber
//     * @param model
//     * @return
//     */
//    @GetMapping("/article/list")
//    public String articleList(HttpServletRequest request, Integer pageNumber, Model model){
//        User user = (User) request.getSession().getAttribute("user");
//        Page<ArticleVo> articlePage = new Page<>(pageNumber,15);
//        IPage<ArticleVo> articleVoIPage = iArticleService.articleList(articlePage,null);
//        model.addAttribute("articleVoIPage", CommonPage.restPage(articleVoIPage));
//        return "/user/articleList";
//    }

    /**
     * 上传文件
     * @param file
     * @return
     */
    @PostMapping("/uploadFile")
    @ResponseBody
    public String uploadFile( MultipartFile file){
        if (file.isEmpty()){
            return null;
        }
        String fileName = file.getOriginalFilename();
        fileName = CommonUtils.getFileName(fileName);
        String filepath = CommonUtils.getUploadPath();
        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(filepath + File.separator + fileName))){
            out.write(file.getBytes());
            out.flush();
            return CommonUtils.getUploadFilePath()+fileName;
        } catch (Exception e) {
//            log.error("上次图片失败"+e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 个人中心
     * @param request
     * @return
     */
    @GetMapping("/manage")
    public String userManage(HttpServletRequest request,Model model){
        User user = (User) request.getSession().getAttribute("user");
        if (Objects.isNull(user)){
            return "redirect:/";
        }
        model.addAttribute("user",user);
        return "/user/userManage";
    }

    /**
     * 发布文章
     * @param request
     * @param model
     * @return
     */
    @GetMapping("/publishArticle")
    public String publishArticle(HttpServletRequest request,Model model){
        User user = (User) request.getSession().getAttribute("user");
        if (Objects.isNull(user)){
            return "redirect:/";
        }
        List<ArticleTag> articleTagList = iArticleTagService.list();
        model.addAttribute("articleTagList",articleTagList);

        return "/user/publishArticle";
    }

    /**
     * 发布文章方法
     * @param publishArticleActionDto
     * @return
     */
    @PostMapping("/publishArticleAction")
    @ResponseBody
    public CommonResult publishArticleAction(HttpServletRequest request,@Valid PublishArticleActionDto publishArticleActionDto){
        return iArticleService.publishArticleAction(request,publishArticleActionDto);
    }

    /**
     * 个人中心，我的文章
     * @param request
     * @param pageNumber
     * @param model
     * @return
     */
    @GetMapping("/myArticleList")
    public String myArticleList(HttpServletRequest request, Integer pageNumber, Model model) {
        User user = (User) request.getSession().getAttribute("user");
        if (Objects.isNull(user)){
            return "/";
        }
        if (Objects.isNull(pageNumber) || pageNumber < 1) {
            pageNumber = 1;
        }
//        Page<ArticleVo> articlePage = new Page<>(pageNumber, 24);
//        IPage<ArticleVo> articleVoIPage = iArticleService.articleList(articlePage, null, user.getUserId());
        List<Article> articleList = iArticleService.list(Wrappers.<Article>lambdaQuery().eq(Article::getUserId,user.getUserId()).select());
        model.addAttribute("articleList", articleList);

        return "/user/myArticleList";
    }

    /**
     * 删除文章
     * @param articleId
     * @return
     */
    @PostMapping("/delArticle")
    @ResponseBody
    public CommonResult delArticle(String articleId){
        iArticleService.removeById(articleId);
        if (iArticleService.updateById(iArticleService.getById(articleId))){
            return CommonResult.success("删除成功");
        }
        return CommonResult.failed("删除sb");
    }

    /**
     * 发表评论
     * @param request
     * @param articleId
     * @param commentContent
     * @return
     */
    @PostMapping("/sendComment")
    @ResponseBody
    public CommonResult sendComment(HttpServletRequest request,String articleId,String commentContent){
        if (StrUtil.isBlank(articleId)||StrUtil.isBlank(commentContent)){
            return CommonResult.failed("发送失败");
        }
        if (commentContent.length()<2||commentContent.length()>1500){
            return CommonResult.failed("评论内容为2-1500字符");
        }
        User user = (User) request.getSession().getAttribute("user");
        if (Objects.isNull(user)){
            return CommonResult.failed("登录过期，请重新登录");
        }
        String userId = user.getUserId();
        Comment comment = iCommentService.getOne(Wrappers.<Comment>lambdaQuery().eq(Comment::getUserId, userId).select(Comment::getCommentTime),false);
        if (Objects.nonNull(comment)&&Objects.nonNull(comment.getCommentTime())){
            if ((comment.getCommentTime().getTime()+5000)>System.currentTimeMillis()){
                return CommonResult.failed("评论过于频繁");
            }
        }
        Comment comment1 = new Comment();
        comment1.setArticleId(articleId);
        comment1.setUserId(userId);
        comment1.setCommentContent(commentContent);
        comment1.setCommentThumbs(0);
        comment1.setCommentTime(DateUtil.date());

        if (iCommentService.save(comment1)){
            CommentVo commentVo = new CommentVo();
            BeanUtils.copyProperties(comment1,commentVo);
            commentVo.setUserName(iUserService.getOne(Wrappers.<User>lambdaQuery().eq(User::getUserId,commentVo.getUserId()).select(User::getUserName)).getUserName());
            return CommonResult.success(commentVo);
        }

        return CommonResult.failed("发送失败");
    }

//    /**
//     * 回复评论
//     * @param request
//     * @param commentId
//     * @param articleId
//     * @param commentContent
//     * @return
//     */
//    @PostMapping("/commentReply")
//    @ResponseBody
//    public CommonResult commentReply(HttpServletRequest request,String commentId,String articleId,String commentContent){
//        if (StrUtil.isBlank(commentId)||StrUtil.isBlank(articleId)||StrUtil.isBlank(commentContent)){
//            return CommonResult.failed("回复失败");
//        }
//        if (commentContent.length() < 2||commentContent.length() > 800){
//            return CommonResult.failed("回复为2-800字符");
//        }
//        User user = (User) request.getSession().getAttribute("user");
//        if (Objects.isNull(user)){
//            return CommonResult.failed("登录过期或未登录");
//        }
//        String userId = user.getUserId();
//
//        CommentReply commentReply = ICommentReplyService.getOne(Wrappers.<CommentReply>lambdaQuery().eq(CommentReply::getReplyUserId, userId).select(Comment::getCommentTime).orderByAsc(Comment::getCommentTime), false);
//        if (Objects.nonNull(comment) && Objects.nonNull(comment.getCommentTime())) {
//            if ((comment.getCommentTime().getTime() + 10000) > System.currentTimeMillis()) {
//                return CommonResult.failed("客官您评论太快啦~~，休息一下吧");
//            }
//        }
//    }

}
