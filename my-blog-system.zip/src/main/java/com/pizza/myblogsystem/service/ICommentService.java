package com.pizza.myblogsystem.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;
import com.pizza.myblogsystem.vo.CommentVo;

import java.util.List;

/**
 * <p>
 * 评论表 服务类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface ICommentService extends IService<Comment> {

    /**
     * 文章评论列表
     * @param articleId
     * @return
     */
    IPage<CommentVo> getCommentList(Page<CommentVo> commentVoPage, String articleId);

}
