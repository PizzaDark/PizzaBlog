package com.pizza.myblogsystem.service;

import com.pizza.myblogsystem.entity.CommentReply;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 评论回复表 服务类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface ICommentReplyService extends IService<CommentReply> {

}
