package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.CommentReply;
import com.pizza.myblogsystem.mapper.CommentReplyMapper;
import com.pizza.myblogsystem.service.ICommentReplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 评论回复表 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class CommentReplyServiceImpl extends ServiceImpl<CommentReplyMapper, CommentReply> implements ICommentReplyService {

}
