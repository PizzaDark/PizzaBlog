package com.pizza.myblogsystem.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.pizza.myblogsystem.dto.Article.PublishArticleActionDto;
import com.pizza.myblogsystem.entity.Article;
import com.pizza.myblogsystem.entity.ArticleTagList;
import com.pizza.myblogsystem.entity.User;
import com.pizza.myblogsystem.exception.CommonException;
import com.pizza.myblogsystem.mapper.ArticleMapper;
import com.pizza.myblogsystem.service.IArticleService;
import com.pizza.myblogsystem.service.IArticleTagListService;
import com.pizza.myblogsystem.utils.CommonResult;
import com.pizza.myblogsystem.vo.ArticleVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;

/**
 * <p>
 * 文章表 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements IArticleService {

    @Autowired
    private ArticleMapper articleMapper;
    @Autowired
    private IArticleTagListService iArticleTagListService;

    /**
     * 文章发布方法
     * @param publishArticleActionDto
     * @return
     */
    public CommonResult publishArticleAction(HttpServletRequest request,PublishArticleActionDto publishArticleActionDto){
        Article article = new Article();
        User user = (User) request.getSession().getAttribute("user");
        article.setUserId(user.getUserId());
        article.setArticleView(0);
        article.setArticleCollection(0);
        article.setArticleContent(publishArticleActionDto.getArticleContent());
        article.setArticleThumbs(0);
        article.setArticleTitle(publishArticleActionDto.getArticleTitle());
        article.setArticlePublishTime(new Date());

        if (!save(article)){
            return CommonResult.failed("发布失败");
        }
        String[] articleTagIds = publishArticleActionDto.getArticleTagIds();
        ArrayList<ArticleTagList> articleTagLists = new ArrayList<>();
        for (String articleTagId : articleTagIds){
            ArticleTagList articleTagList = new ArticleTagList();
            articleTagList.setArticleTagId(articleTagId);
            articleTagList.setArticleId(article.getArticleId());
        }
        if (!iArticleTagListService.saveBatch(articleTagLists,50)){
            throw new CommonException("发布失败");
        }
        return CommonResult.success("发布成功");
    }

    /**
     * 根据id获取文章
     * @param articleId
     * @return
     */
    @Override
    public Article getArticle(String articleId){
        return articleMapper.getArticle(articleId);
    }

    /**
     * 文章列表
     *
     * @param articlePage
     * @param articleTitle
     * @return
     */
    @Override
    public IPage<ArticleVo> articleList(IPage<ArticleVo> articlePage, String articleTitle, String userId) {
        return articleMapper.articleList(articlePage, articleTitle, userId);
    }

    /**
     * 文章列表 前端
     *
     * @param articlePage
     * @param articleTitle
     * @return
     */
    @Override
    public IPage<ArticleVo> articleListView(Page<ArticleVo> articlePage, String articleTitle) {
        return articleMapper.articleListView(articlePage, articleTitle);
    }

}
