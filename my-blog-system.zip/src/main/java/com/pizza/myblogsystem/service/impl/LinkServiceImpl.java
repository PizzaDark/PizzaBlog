package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.Link;
import com.pizza.myblogsystem.mapper.LinkMapper;
import com.pizza.myblogsystem.service.ILinkService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 链接 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class LinkServiceImpl extends ServiceImpl<LinkMapper, Link> implements ILinkService {

}
