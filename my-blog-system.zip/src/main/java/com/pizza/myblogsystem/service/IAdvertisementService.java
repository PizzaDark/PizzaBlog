package com.pizza.myblogsystem.service;

import com.pizza.myblogsystem.entity.Advertisement;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 广告 服务类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface IAdvertisementService extends IService<Advertisement> {

}
