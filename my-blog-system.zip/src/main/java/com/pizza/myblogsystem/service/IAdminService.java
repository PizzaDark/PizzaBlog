package com.pizza.myblogsystem.service;

import com.pizza.myblogsystem.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 管理员表 服务类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-10
 */
public interface IAdminService extends IService<Admin> {

}
