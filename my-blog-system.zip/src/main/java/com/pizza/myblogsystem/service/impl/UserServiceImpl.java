package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.User;
import com.pizza.myblogsystem.mapper.UserMapper;
import com.pizza.myblogsystem.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

}
