package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.AdType;
import com.pizza.myblogsystem.mapper.AdTypeMapper;
import com.pizza.myblogsystem.service.IAdTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 广告类型 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class AdTypeServiceImpl extends ServiceImpl<AdTypeMapper, AdType> implements IAdTypeService {

}
