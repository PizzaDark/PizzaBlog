package com.pizza.myblogsystem.service;

import com.pizza.myblogsystem.entity.ArticleTagList;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface IArticleTagListService extends IService<ArticleTagList> {

}
