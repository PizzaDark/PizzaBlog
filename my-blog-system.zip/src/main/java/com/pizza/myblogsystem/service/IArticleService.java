package com.pizza.myblogsystem.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.dto.Article.PublishArticleActionDto;
import com.pizza.myblogsystem.entity.Article;
import com.baomidou.mybatisplus.extension.service.IService;
import com.pizza.myblogsystem.utils.CommonResult;
import com.pizza.myblogsystem.vo.ArticleVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 文章表 服务类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
public interface IArticleService extends IService<Article> {

//    /**
//     * 文章列表
//     * @param articlePage
//     * @param articleTitle
//     * @return
//     */
//    IPage<ArticleVo> articleList(IPage<ArticleVo> articlePage, String articleTitle);
//
//    /**
//     * 文章列表方法
//     * @param articlePage
//     * @param articleTitle
//     * @return
//     */
//    IPage<ArticleVo> articleListView(Page<ArticleVo> articlePage,String articleTitle);

    /**
     * 文章发布方法
     * @param publishArticleActionDto
     * @return
     */
    CommonResult publishArticleAction(HttpServletRequest request,PublishArticleActionDto publishArticleActionDto);

    /**
     * 根据id获取文章
     * @param articleId
     * @return
     */
    Article getArticle(String articleId);

    IPage<ArticleVo> articleList(IPage<ArticleVo> articlePage, String articleTitle, String userId);

    IPage<ArticleVo> articleListView(Page<ArticleVo> articlePage, String articleTitle);

}
