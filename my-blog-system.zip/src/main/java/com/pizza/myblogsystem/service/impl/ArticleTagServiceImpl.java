package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.ArticleTag;
import com.pizza.myblogsystem.mapper.ArticleTagMapper;
import com.pizza.myblogsystem.service.IArticleTagService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 文章标签表 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class ArticleTagServiceImpl extends ServiceImpl<ArticleTagMapper, ArticleTag> implements IArticleTagService {

}
