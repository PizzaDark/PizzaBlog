package com.pizza.myblogsystem.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.pizza.myblogsystem.entity.Comment;
import com.pizza.myblogsystem.mapper.CommentMapper;
import com.pizza.myblogsystem.service.ICommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.pizza.myblogsystem.vo.CommentVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 评论表 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements ICommentService {

    @Autowired
    private CommentMapper commentMapper;
    /**
     * 文章评论列表
     * @param articleId
     * @return
     */
    @Override
    public IPage<CommentVo> getCommentList(Page<CommentVo> commentVoPage, String articleId){
        return commentMapper.getCommentList(commentVoPage,articleId);
    }

}
