package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.Advertisement;
import com.pizza.myblogsystem.mapper.AdvertisementMapper;
import com.pizza.myblogsystem.service.IAdvertisementService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 广告 服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class AdvertisementServiceImpl extends ServiceImpl<AdvertisementMapper, Advertisement> implements IAdvertisementService {

}
