package com.pizza.myblogsystem.service.impl;

import com.pizza.myblogsystem.entity.ArticleTagList;
import com.pizza.myblogsystem.mapper.ArticleTagListMapper;
import com.pizza.myblogsystem.service.IArticleTagListService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Service
public class ArticleTagListServiceImpl extends ServiceImpl<ArticleTagListMapper, ArticleTagList> implements IArticleTagListService {

}
