package com.pizza.myblogsystem.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.pizza.myblogsystem.entity.Comment;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.util.Date;

@Data
public class CommentVo {

    /**
     * 评论id
     */
    private String commentId;

    /**
     * 文章id
     */
    private String articleId;

    /**
     * 发评论者
     */
    private String userId;

    /**
     * 评论时间
     */
    private Date commentTime;

    /**
     * 评论获赞
     */
    private Integer commentThumbs;

    /**
     * 评论内容
     */
    private String commentContent;

    /**
     * 用户名
     */
    @TableField(exist = false)
    private String userName;

}
