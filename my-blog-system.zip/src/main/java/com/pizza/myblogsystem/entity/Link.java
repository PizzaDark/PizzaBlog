package com.pizza.myblogsystem.entity;

import java.time.LocalDateTime;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 链接
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Link implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 链接id
     */
    @TableId(value = "link_id")
    private String linkId;

    /**
     * 链接名
     */
    private String linkName;

    /**
     * 链接地址
     */
    private String linkUrl;

    private String linkIcon;

    private String linkIconUrl;

    private LocalDateTime linkSendTime;


}
