package com.pizza.myblogsystem.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 评论表
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论id
     */
    @TableId(value = "comment_id")
    private String commentId;

    /**
     * 文章id
     */
    private String articleId;

    /**
     * 发评论者
     */
    private String userId;

    /**
     * 评论时间
     */
    private Date commentTime;

    /**
     * 评论获赞
     */
    private Integer commentThumbs;

    /**
     * 评论内容
     */
    private String commentContent;

}
