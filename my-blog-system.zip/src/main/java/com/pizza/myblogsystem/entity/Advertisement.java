package com.pizza.myblogsystem.entity;

import java.time.LocalDateTime;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 广告
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Advertisement implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 广告id
     */
    @TableId(value = "advertisement_id")
    private String adId;

    /**
     * 广告类型号id
     */
    private String adTypeId;

    /**
     * 广告标题
     */
    private String adTitle;

    /**
     * 广告链接
     */
    private String adUrl;

    /**
     * 广告排序
     */
    private Integer adSort;

    /**
     * 广告开始时间
     */
    private LocalDateTime adStartTime;

    /**
     * 广告结束时间
     */
    private LocalDateTime adEndTime;

    private LocalDateTime adAddTime;


}
