package com.pizza.myblogsystem.entity;

import java.time.LocalDateTime;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 广告类型
 * </p>
 *
 * @author 侯征
 * @since 2023-08-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class AdType implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 广告类型号id
     */
    @TableId(value = "ad_type_id")
    private String adTypeId;

    /**
     * 广告类型名
     */
    private String adTypeName;

    /**
     * 广告标识
     */
    private String adTypeTag;

    /**
     * 广告类型排序
     */
    private Integer adTypeSort;

    private LocalDateTime adTypeAddTime;


}
