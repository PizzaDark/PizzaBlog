package com.pizza.myblogsystem.dto.Article;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;

@Data
public class PublishArticleActionDto {

    /**
     * 文章标题
     */
    @NotBlank(message = "标题不能为空")
    @Length(max = 50,message = "标题最多50字符")
    private String articleTitle;

    /**
     * 标签id列表
     */
    private String[] articleTagIds;

    /**
     * 文章内容
     */
    @NotBlank(message = "内容不能为空")
    @Length(min = 5,max = 15000,message = "内容为5-15000字符")
    private String articleContent;
}
