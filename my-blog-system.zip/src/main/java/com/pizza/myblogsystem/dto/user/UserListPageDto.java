package com.pizza.myblogsystem.dto.user;

import com.pizza.myblogsystem.dto.base.BasePageDto;
import lombok.Data;

@Data
public class UserListPageDto extends BasePageDto {

    /**
     * 用户名
     */
    private String userName;
}
