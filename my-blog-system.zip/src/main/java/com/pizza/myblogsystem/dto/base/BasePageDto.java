package com.pizza.myblogsystem.dto.base;

import lombok.Data;
import javax.validation.constraints.NotNull;

@Data
public class BasePageDto {

    /**
     * 当前页码
     */
    @NotNull(message = "未获取当前页码")
    private Integer pageNumber = 1;

    /**
     * 每页数据数
     */
    private Integer pageSize = 20;
}
